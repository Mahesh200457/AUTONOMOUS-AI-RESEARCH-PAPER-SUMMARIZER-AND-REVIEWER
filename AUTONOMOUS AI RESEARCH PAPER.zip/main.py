from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import asyncio
import time
from datetime import datetime
from loguru import logger

# Import services
from services.pdf_processor import PDFProcessor
from services.text_processor import TextProcessor
from services.section_detector import SectionDetector
from services.keyword_extractor import KeywordExtractor
from services.ai_analyzer import AIAnalyzer

# Import models and utilities
from models.response_models import AnalysisResponse
from utils.validators import FileValidator

# Configure logging
logger.add("app.log", rotation="500 MB", level="INFO")

# Initialize FastAPI app
app = FastAPI(
    title="Autonomous AI Research Paper Summarizer and Reviewer",
    description="A production-ready backend system for automated research paper analysis, summarization, and review using AI",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
app.mount("/static", StaticFiles(directory="static"), name="static")

# Initialize services
pdf_processor = PDFProcessor()
text_processor = TextProcessor()
section_detector = SectionDetector()
keyword_extractor = KeywordExtractor()
ai_analyzer = AIAnalyzer()

@app.get("/")
async def serve_frontend():
    """Serve the frontend HTML file"""
    from fastapi.responses import FileResponse
    return FileResponse('static/index.html')

@app.get("/api")
async def root():
    """Health check endpoint"""
    return {
        "message": "Autonomous AI Research Paper Summarizer and Reviewer",
        "status": "active",
        "version": "1.0.0",
        "timestamp": datetime.now()
    }

@app.get("/api/health")
async def health_check():
    """Detailed health check"""
    return {
        "status": "healthy",
        "services": {
            "pdf_processor": "active",
            "text_processor": "active",
            "ai_analyzer": "active",
            "keyword_extractor": "active"
        },
        "timestamp": datetime.now()
    }

@app.post("/api/analyze-paper", response_model=AnalysisResponse)
async def analyze_paper(file: UploadFile = File(...)):
    """
    Main endpoint for analyzing research papers
    
    Accepts a PDF file and returns comprehensive analysis including:
    - Text extraction and section detection
    - Keyword extraction
    - AI-generated summaries
    - Research topic identification
    - Comprehensive reviewer report with scores
    """
    start_time = time.time()
    
    try:
        # Read file content
        file_content = await file.read()
        logger.info(f"Processing file: {file.filename} ({len(file_content)} bytes)")
        
        # Validate file
        FileValidator.validate_pdf_file(file_content, file.filename)
        
        # Step 1: Extract text from PDF
        logger.info("Extracting text from PDF...")
        full_text, document_title = await pdf_processor.extract_text_from_pdf(file_content)
        
        # Step 2: Clean text
        logger.info("Cleaning extracted text...")
        cleaned_text = await text_processor.clean_text(full_text)
        
        # Step 3: Detect sections
        logger.info("Detecting document sections...")
        sections = section_detector.detect_sections(cleaned_text)
        
        # Step 4: Generate section summaries
        logger.info("Generating section summaries...")
        section_summaries = await ai_analyzer.generate_section_summaries(sections)
        
        # Step 5: Extract keywords
        logger.info("Extracting keywords...")
        preprocessed_text = await text_processor.preprocess_for_keywords(cleaned_text)
        top_keywords = await keyword_extractor.extract_keywords(preprocessed_text, top_n=15)
        
        # Step 6: Generate overall summaries
        logger.info("Generating overall summaries...")
        short_summary, detailed_summary = await ai_analyzer.generate_overall_summaries(cleaned_text)
        
        # Step 7: Identify research topics
        logger.info("Identifying research topics...")
        research_topics = await ai_analyzer.identify_research_topics(cleaned_text)
        
        # Step 8: Generate reviewer report
        logger.info("Generating AI reviewer report...")
        reviewer_report = await ai_analyzer.generate_reviewer_report(cleaned_text)
        
        # Step 9: Calculate analytics
        processing_time = time.time() - start_time
        original_word_count = len(full_text.split())
        short_summary_word_count = len(short_summary.split())
        detailed_summary_word_count = len(detailed_summary.split())
        
        compression_percentage_short = (short_summary_word_count / original_word_count) * 100 if original_word_count > 0 else 0
        compression_percentage_detailed = (detailed_summary_word_count / original_word_count) * 100 if original_word_count > 0 else 0
        
        # Prepare response
        response = AnalysisResponse(
            document_title=document_title,
            extracted_text_preview=full_text[:500] + "..." if len(full_text) > 500 else full_text,
            detected_sections=list(sections.keys()),
            section_summaries=section_summaries,
            top_keywords=top_keywords,
            short_summary=short_summary,
            detailed_summary=detailed_summary,
            research_topics=research_topics,
            reviewer_report=reviewer_report,
            analytics={
                "original_word_count": original_word_count,
                "short_summary_word_count": short_summary_word_count,
                "detailed_summary_word_count": detailed_summary_word_count,
                "compression_percentage_short": round(compression_percentage_short, 2),
                "compression_percentage_detailed": round(compression_percentage_detailed, 2),
                "processing_time_seconds": round(processing_time, 2)
            },
            timestamp=datetime.now()
        )
        
        logger.info(f"Analysis completed successfully in {processing_time:.2f} seconds")
        return response
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error analyzing paper: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error during paper analysis: {str(e)}"
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)