import spacy
import re
import asyncio
from typing import List, Dict
from loguru import logger

class TextProcessor:
    """Service for text preprocessing and cleaning"""
    
    def __init__(self):
        self.nlp = None
        self._load_spacy_model()
    
    def _load_spacy_model(self):
        """Load spaCy model"""
        try:
            self.nlp = spacy.load("en_core_web_sm")
        except OSError:
            logger.warning("spaCy model 'en_core_web_sm' not found. Using basic processing.")
            self.nlp = None
    
    async def clean_text(self, text: str) -> str:
        """Clean and preprocess text"""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._clean_text_sync, text)
    
    def _clean_text_sync(self, text: str) -> str:
        """Synchronous text cleaning"""
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove page numbers and headers/footers patterns
        text = re.sub(r'\b\d+\s*$', '', text, flags=re.MULTILINE)
        text = re.sub(r'^.*?(?:Page|PAGE)\s*\d+.*?$', '', text, flags=re.MULTILINE)
        
        # Remove references/citations patterns
        text = re.sub(r'\[\d+\]', '', text)
        text = re.sub(r'\(\d{4}\)', '', text)
        
        # Remove URLs
        text = re.sub(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', '', text)
        
        # Clean up multiple periods
        text = re.sub(r'\.{3,}', '...', text)
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text).strip()
        
        return text
    
    async def preprocess_for_keywords(self, text: str) -> str:
        """Preprocess text specifically for keyword extraction"""
        if not self.nlp:
            return await self._basic_preprocess(text)
        
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self._preprocess_with_spacy, text)
    
    def _preprocess_with_spacy(self, text: str) -> str:
        """Advanced preprocessing with spaCy"""
        # Process text with spaCy
        doc = self.nlp(text[:1000000])  # Limit text length for processing
        
        # Extract meaningful tokens (lemmatized)
        tokens = []
        for token in doc:
            if (not token.is_stop and 
                not token.is_punct and 
                not token.is_space and 
                len(token.text) > 2 and
                token.pos_ in ['NOUN', 'ADJ', 'VERB', 'PROPN']):
                tokens.append(token.lemma_.lower())
        
        return ' '.join(tokens)
    
    async def _basic_preprocess(self, text: str) -> str:
        """Basic preprocessing without spaCy"""
        # Convert to lowercase
        text = text.lower()
        
        # Remove punctuation and numbers
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\d+', '', text)
        
        # Remove common stop words
        stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'should', 'could', 'can', 'may', 'might', 'must', 'this', 'that', 'these', 'those'}
        
        words = text.split()
        filtered_words = [word for word in words if word not in stop_words and len(word) > 2]
        
        return ' '.join(filtered_words)