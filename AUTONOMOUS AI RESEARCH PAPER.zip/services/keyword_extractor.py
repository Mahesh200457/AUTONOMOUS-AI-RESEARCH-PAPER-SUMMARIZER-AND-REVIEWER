from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np
import asyncio
from typing import List
from loguru import logger

class KeywordExtractor:
    """Service for extracting keywords using TF-IDF"""
    
    def __init__(self):
        self.vectorizer = TfidfVectorizer(
            max_features=500,
            stop_words='english',
            ngram_range=(1, 3),  # Include unigrams, bigrams, and trigrams
            min_df=1,
            max_df=0.8
        )
    
    async def extract_keywords(self, text: str, top_n: int = 15) -> List[str]:
        """Extract top N keywords from text using TF-IDF"""
        try:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(
                None, 
                self._extract_keywords_sync, 
                text, 
                top_n
            )
        except Exception as e:
            logger.error(f"Error extracting keywords: {e}")
            return []
    
    def _extract_keywords_sync(self, text: str, top_n: int) -> List[str]:
        """Synchronous keyword extraction"""
        try:
            # Split text into sentences to create a small corpus
            sentences = self._split_into_sentences(text)
            
            if len(sentences) < 2:
                # If too few sentences, split by paragraphs
                sentences = [p.strip() for p in text.split('\n\n') if p.strip()]
            
            if len(sentences) < 2:
                # Last resort: create artificial documents
                words = text.split()
                chunk_size = max(50, len(words) // 5)
                sentences = [' '.join(words[i:i+chunk_size]) 
                           for i in range(0, len(words), chunk_size)]
            
            # Fit TF-IDF vectorizer
            tfidf_matrix = self.vectorizer.fit_transform(sentences)
            
            # Get feature names (terms)
            feature_names = self.vectorizer.get_feature_names_out()
            
            # Calculate mean TF-IDF score for each term across all documents
            mean_scores = np.mean(tfidf_matrix.toarray(), axis=0)
            
            # Get indices of top scoring terms
            top_indices = np.argsort(mean_scores)[::-1][:top_n]
            
            # Extract top keywords
            top_keywords = [feature_names[i] for i in top_indices if mean_scores[i] > 0]
            
            return top_keywords[:top_n]
            
        except Exception as e:
            logger.error(f"Error in keyword extraction: {e}")
            # Fallback: simple word frequency
            return self._fallback_keyword_extraction(text, top_n)
    
    def _split_into_sentences(self, text: str) -> List[str]:
        """Split text into sentences"""
        import re
        # Simple sentence splitting
        sentences = re.split(r'[.!?]+', text)
        sentences = [s.strip() for s in sentences if len(s.strip()) > 20]
        return sentences
    
    def _fallback_keyword_extraction(self, text: str, top_n: int) -> List[str]:
        """Fallback keyword extraction using simple word frequency"""
        import re
        from collections import Counter
        
        # Clean and tokenize
        words = re.findall(r'\b[a-zA-Z]{3,}\b', text.lower())
        
        # Remove common stop words
        stop_words = {'the', 'and', 'for', 'are', 'but', 'not', 'you', 'all', 'can', 'had', 'her', 'was', 'one', 'our', 'out', 'day', 'get', 'has', 'him', 'his', 'how', 'its', 'may', 'new', 'now', 'old', 'see', 'two', 'who', 'boy', 'did', 'she', 'use', 'her', 'way', 'many', 'then', 'them', 'these', 'this', 'that', 'than', 'they', 'been', 'call', 'came', 'each', 'have', 'into', 'like', 'look', 'make', 'more', 'over', 'said', 'some', 'time', 'very', 'what', 'will', 'with', 'your'}
        
        filtered_words = [word for word in words if word not in stop_words]
        
        # Count frequency
        word_counts = Counter(filtered_words)
        
        # Return top words
        return [word for word, _ in word_counts.most_common(top_n)]