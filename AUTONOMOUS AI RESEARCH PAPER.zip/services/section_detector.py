import re
from typing import Dict, List, Tuple
from loguru import logger

class SectionDetector:
    """Service for detecting and extracting sections from research papers"""
    
    def __init__(self):
        # Define section patterns (case-insensitive)
        self.section_patterns = {
            'Abstract': [
                r'\babstract\b',
                r'\bsummary\b'
            ],
            'Introduction': [
                r'\bintroduction\b',
                r'\b1\.?\s*introduction\b',
                r'\bbackground\b'
            ],
            'Methodology': [
                r'\bmethodology\b',
                r'\bmethods\b',
                r'\bmaterial and methods\b',
                r'\bmaterials and methods\b',
                r'\bexperimental setup\b',
                r'\bexperimental design\b'
            ],
            'Results': [
                r'\bresults\b',
                r'\bfindings\b',
                r'\bexperimental results\b'
            ],
            'Conclusion': [
                r'\bconclusion\b',
                r'\bconclusions\b',
                r'\bdiscussion and conclusion\b',
                r'\bfinal remarks\b'
            ]
        }
    
    def detect_sections(self, text: str) -> Dict[str, str]:
        """
        Detect and extract sections from text
        Returns: Dictionary with section names as keys and content as values
        """
        sections = {}
        
        try:
            # Split text into lines for processing
            lines = text.split('\n')
            
            # Find section boundaries
            section_boundaries = self._find_section_boundaries(lines)
            
            # Extract content for each detected section
            for section_name, (start_idx, end_idx) in section_boundaries.items():
                section_content = '\n'.join(lines[start_idx:end_idx])
                sections[section_name] = self._clean_section_content(section_content)
            
            # If no sections detected, try alternative approach
            if not sections:
                sections = self._extract_sections_fallback(text)
            
        except Exception as e:
            logger.error(f"Error detecting sections: {e}")
            # Fallback: return entire text as one section
            sections = {"Full Document": text[:5000]}  # Limit length
        
        return sections
    
    def _find_section_boundaries(self, lines: List[str]) -> Dict[str, Tuple[int, int]]:
        """Find start and end boundaries for each section"""
        boundaries = {}
        section_starts = []
        
        # Find section headers
        for i, line in enumerate(lines):
            line_clean = line.strip().lower()
            
            for section_name, patterns in self.section_patterns.items():
                for pattern in patterns:
                    if re.search(pattern, line_clean, re.IGNORECASE):
                        section_starts.append((i, section_name))
                        break
        
        # Sort by line number
        section_starts.sort(key=lambda x: x[0])
        
        # Determine boundaries
        for i, (start_line, section_name) in enumerate(section_starts):
            # Section ends where next section starts, or at end of document
            if i + 1 < len(section_starts):
                end_line = section_starts[i + 1][0]
            else:
                end_line = len(lines)
            
            boundaries[section_name] = (start_line, end_line)
        
        return boundaries
    
    def _extract_sections_fallback(self, text: str) -> Dict[str, str]:
        """Fallback method when header-based detection fails"""
        sections = {}
        
        # Simple keyword-based extraction
        text_lower = text.lower()
        
        for section_name, patterns in self.section_patterns.items():
            for pattern in patterns:
                match = re.search(pattern + r'(.{0,2000}?)(?=' + '|'.join([p for sublist in self.section_patterns.values() for p in sublist if p != pattern]) + '|$)', text_lower, re.IGNORECASE | re.DOTALL)
                if match:
                    # Find the actual position in original text
                    start_pos = text_lower.find(match.group(0))
                    if start_pos != -1:
                        content = text[start_pos:start_pos + len(match.group(0))]
                        sections[section_name] = self._clean_section_content(content)
                    break
        
        return sections
    
    def _clean_section_content(self, content: str) -> str:
        """Clean section content"""
        # Remove the section header itself
        lines = content.split('\n')
        if lines:
            # Skip the first line (likely the header)
            content = '\n'.join(lines[1:])
        
        # Clean up whitespace
        content = re.sub(r'\n\s*\n', '\n\n', content)
        content = content.strip()
        
        # Limit content length to prevent excessive text
        if len(content) > 3000:
            content = content[:3000] + "..."
        
        return content