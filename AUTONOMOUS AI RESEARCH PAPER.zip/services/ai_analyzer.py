import google.generativeai as genai
import asyncio
import json
from typing import Dict, List, Tuple
from loguru import logger
from config import config

class AIAnalyzer:
    """Service for AI-powered analysis using Google Gemini"""
    
    def __init__(self):
        # Configure Gemini API
        genai.configure(api_key=config.GEMINI_API_KEY)
        self.model = genai.GenerativeModel(config.GEMINI_MODEL)
    
    async def generate_section_summaries(self, sections: Dict[str, str]) -> List[Dict[str, str]]:
        """Generate summaries for each section"""
        summaries = []
        
        for section_name, content in sections.items():
            try:
                prompt = f"""
                Summarize the following {section_name} section from a research paper in 2-3 sentences:
                
                {content[:1500]}
                
                Provide a concise, academic summary that captures the key points.
                """
                
                summary = await self._generate_text(prompt)
                summaries.append({
                    "section_name": section_name,
                    "content": content[:500],  # Truncated for response
                    "summary": summary,
                    "word_count": len(content.split())
                })
                
            except Exception as e:
                logger.error(f"Error summarizing {section_name}: {e}")
                summaries.append({
                    "section_name": section_name,
                    "content": content[:500],
                    "summary": f"Unable to generate summary for {section_name}",
                    "word_count": len(content.split())
                })
        
        return summaries
    
    async def generate_overall_summaries(self, full_text: str) -> Tuple[str, str]:
        """Generate short (150 words) and detailed (500 words) summaries"""
        short_summary_prompt = f"""
        Provide a concise 150-word summary of this research paper:
        
        {full_text[:3000]}
        
        Focus on: main research question, methodology, key findings, and significance.
        """
        
        detailed_summary_prompt = f"""
        Provide a comprehensive 500-word summary of this research paper:
        
        {full_text[:5000]}
        
        Include: background, objectives, methodology, key results, implications, and conclusions.
        Structure it in clear paragraphs.
        """
        
        try:
            short_summary = await self._generate_text(short_summary_prompt)
            detailed_summary = await self._generate_text(detailed_summary_prompt)
            return short_summary, detailed_summary
        except Exception as e:
            logger.error(f"Error generating overall summaries: {e}")
            return "Unable to generate short summary", "Unable to generate detailed summary"
    
    async def identify_research_topics(self, text: str) -> Dict[str, List[str]]:
        """Identify main and secondary research topics"""
        prompt = f"""
        Analyze this research paper and identify the research topics. Return your response in JSON format:
        
        {text[:4000]}
        
        Provide:
        {{
            "main_topics": ["topic1", "topic2", "topic3"],
            "secondary_topics": ["topic1", "topic2", "topic3", "topic4", "topic5"]
        }}
        
        Main topics should be 3 primary research areas. Secondary topics should be 5 related or supporting areas.
        """
        
        try:
            response = await self._generate_text(prompt)
            # Try to parse JSON response
            try:
                topics = json.loads(response)
                return topics
            except json.JSONDecodeError:
                # Fallback parsing
                return self._parse_topics_fallback(response)
        except Exception as e:
            logger.error(f"Error identifying research topics: {e}")
            return {
                "main_topics": ["Unable to identify topics"],
                "secondary_topics": ["Analysis failed"]
            }
    
    async def generate_reviewer_report(self, text: str) -> Dict:
        """Generate comprehensive AI reviewer report"""
        prompt = f"""
        As an AI academic reviewer, analyze this research paper and provide a comprehensive review. 
        Return your response in JSON format:
        
        {text[:6000]}
        
        Provide a detailed review with this structure:
        {{
            "novelty_assessment": "Detailed assessment of the research novelty and originality",
            "clarity_assessment": "Assessment of writing clarity, organization, and presentation",
            "methodology_quality": "Evaluation of research methods, experimental design, and rigor",
            "strengths": ["strength1", "strength2", "strength3"],
            "weaknesses": ["weakness1", "weakness2", "weakness3"],
            "limitations": ["limitation1", "limitation2"],
            "research_gaps": ["gap1", "gap2"],
            "future_work_suggestions": ["suggestion1", "suggestion2", "suggestion3"],
            "scores": {{
                "novelty": 7,
                "clarity": 8,
                "methodology": 6,
                "overall_quality": 7
            }}
        }}
        
        Provide numerical scores from 1-10 where:
        1-3: Poor, 4-5: Fair, 6-7: Good, 8-9: Very Good, 10: Excellent
        """
        
        try:
            response = await self._generate_text(prompt)
            try:
                review = json.loads(response)
                return review
            except json.JSONDecodeError:
                return self._parse_review_fallback(response)
        except Exception as e:
            logger.error(f"Error generating reviewer report: {e}")
            return self._default_review_report()
    
    async def _generate_text(self, prompt: str) -> str:
        """Generate text using Gemini API"""
        try:
            loop = asyncio.get_event_loop()
            response = await loop.run_in_executor(
                None,
                lambda: self.model.generate_content(
                    prompt,
                    generation_config=genai.types.GenerationConfig(**config.GENERATION_CONFIG)
                )
            )
            return response.text
        except Exception as e:
            logger.error(f"Error calling Gemini API: {e}")
            raise
    
    def _parse_topics_fallback(self, response: str) -> Dict[str, List[str]]:
        """Fallback parsing for research topics"""
        return {
            "main_topics": ["Topic extraction failed", "Please review manually"],
            "secondary_topics": ["Analysis incomplete", "Manual review needed"]
        }
    
    def _parse_review_fallback(self, response: str) -> Dict:
        """Fallback parsing for reviewer report"""
        return self._default_review_report()
    
    def _default_review_report(self) -> Dict:
        """Default review report when analysis fails"""
        return {
            "novelty_assessment": "Unable to assess novelty due to analysis error",
            "clarity_assessment": "Unable to assess clarity due to analysis error",
            "methodology_quality": "Unable to assess methodology due to analysis error",
            "strengths": ["Analysis failed"],
            "weaknesses": ["Unable to determine"],
            "limitations": ["Analysis incomplete"],
            "research_gaps": ["Unable to identify"],
            "future_work_suggestions": ["Manual review required"],
            "scores": {
                "novelty": 5,
                "clarity": 5,
                "methodology": 5,
                "overall_quality": 5
            }
        }