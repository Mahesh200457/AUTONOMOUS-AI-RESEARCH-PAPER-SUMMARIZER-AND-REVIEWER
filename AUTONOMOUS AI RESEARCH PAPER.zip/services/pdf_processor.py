import fitz  # PyMuPDF
import asyncio
from typing import Tuple, Optional
from loguru import logger

class PDFProcessor:
    """Service for extracting text from PDF files"""
    
    @staticmethod
    async def extract_text_from_pdf(pdf_content: bytes) -> Tuple[str, str]:
        """
        Extract text from PDF content
        Returns: (full_text, document_title)
        """
        try:
            # Run PDF processing in thread pool to avoid blocking
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None, 
                PDFProcessor._extract_text_sync, 
                pdf_content
            )
            return result
        except Exception as e:
            logger.error(f"Error extracting text from PDF: {e}")
            raise ValueError(f"Failed to extract text from PDF: {str(e)}")
    
    @staticmethod
    def _extract_text_sync(pdf_content: bytes) -> Tuple[str, str]:
        """Synchronous PDF text extraction"""
        doc = fitz.open(stream=pdf_content, filetype="pdf")
        
        full_text = ""
        document_title = "Unknown Title"
        
        try:
            # Try to get title from metadata
            metadata = doc.metadata
            if metadata and metadata.get('title'):
                document_title = metadata['title'].strip()
            
            # Extract text from all pages
            for page_num in range(len(doc)):
                page = doc[page_num]
                page_text = page.get_text()
                
                # If title not found in metadata, try to extract from first page
                if page_num == 0 and document_title == "Unknown Title":
                    lines = page_text.split('\n')
                    for line in lines[:10]:  # Check first 10 lines
                        if line.strip() and len(line.strip()) > 10:
                            document_title = line.strip()
                            break
                
                full_text += page_text + "\n"
            
        finally:
            doc.close()
        
        if not full_text.strip():
            raise ValueError("No text content found in PDF")
            
        return full_text.strip(), document_title