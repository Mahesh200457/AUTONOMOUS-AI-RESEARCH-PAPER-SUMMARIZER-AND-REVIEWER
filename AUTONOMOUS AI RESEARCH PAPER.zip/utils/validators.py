from fastapi import HTTPException
from config import config
import magic
import os

class FileValidator:
    """Utility class for file validation"""
    
    @staticmethod
    def validate_pdf_file(file_content: bytes, filename: str) -> None:
        """Validate PDF file content and size"""
        
        # Check file size
        if len(file_content) > config.MAX_FILE_SIZE:
            raise HTTPException(
                status_code=413,
                detail=f"File size exceeds maximum limit of {config.MAX_FILE_SIZE / 1024 / 1024:.1f}MB"
            )
        
        # Check file extension
        file_extension = os.path.splitext(filename)[1].lower()
        if file_extension not in config.ALLOWED_EXTENSIONS:
            raise HTTPException(
                status_code=400,
                detail=f"File type not allowed. Only {', '.join(config.ALLOWED_EXTENSIONS)} files are supported."
            )
        
        # Check file content (magic bytes)
        try:
            # Check if it's actually a PDF file
            if not file_content.startswith(b'%PDF'):
                raise HTTPException(
                    status_code=400,
                    detail="Invalid PDF file format"
                )
        except Exception:
            raise HTTPException(
                status_code=400,
                detail="Unable to validate file format"
            )
        
        # Check for minimum file size (empty files)
        if len(file_content) < 100:
            raise HTTPException(
                status_code=400,
                detail="File appears to be empty or corrupted"
            )