const express = require('express');
const multer = require('multer');
const pdfParse = require('pdf-parse');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
require('dotenv').config();
const { GoogleGenerativeAI } = require('@google/generative-ai');
const natural = require('natural');
const nlp = require('compromise');

const app = express();
const PORT = process.env.PORT || 8000;

// Initialize Gemini AI
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || 'AIzaSyBzV0HN4bG75hYGZWjJC2ybpZwkkMhYUQY');
const model = genAI.getGenerativeModel({ model: "gemini-pro" });

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('static'));

// Configure multer for file uploads
const upload = multer({
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Only PDF files are allowed'), false);
    }
  }
});

// Text preprocessing function
function preprocessText(text) {
  // Clean and normalize text
  let cleaned = text
    .replace(/\s+/g, ' ')
    .replace(/[^\w\s\.\,\!\?\;\:\-\(\)]/g, '')
    .trim();
  
  return cleaned;
}

// Section detection function
function detectSections(text) {
  const sections = {
    abstract: '',
    introduction: '',
    methodology: '',
    results: '',
    conclusion: ''
  };

  const sectionPatterns = {
    abstract: /(?:^|\n)\s*(?:abstract|summary)\s*:?\s*\n?(.*?)(?=\n\s*(?:introduction|keywords|1\.|i\.|background)|$)/is,
    introduction: /(?:^|\n)\s*(?:introduction|background|1\.|i\.)\s*:?\s*\n?(.*?)(?=\n\s*(?:methodology|method|literature|related|2\.|ii\.)|$)/is,
    methodology: /(?:^|\n)\s*(?:methodology|method|approach|materials|experimental|2\.|ii\.)\s*:?\s*\n?(.*?)(?=\n\s*(?:results|findings|analysis|3\.|iii\.)|$)/is,
    results: /(?:^|\n)\s*(?:results|findings|analysis|experiments|3\.|iii\.)\s*:?\s*\n?(.*?)(?=\n\s*(?:discussion|conclusion|4\.|iv\.)|$)/is,
    conclusion: /(?:^|\n)\s*(?:conclusion|discussion|summary|future|4\.|iv\.)\s*:?\s*\n?(.*?)(?=\n\s*(?:references|bibliography|acknowledgment)|$)/is
  };

  for (const [section, pattern] of Object.entries(sectionPatterns)) {
    const match = text.match(pattern);
    if (match && match[1]) {
      sections[section] = preprocessText(match[1].substring(0, 2000));
    }
  }

  return sections;
}

// Keyword extraction using TF-IDF
function extractKeywords(text, topN = 15) {
  try {
    const TfIdf = natural.TfIdf;
    const tfidf = new TfIdf();
    
    // Tokenize and clean text
    const tokens = natural.WordTokenizer().tokenize(text.toLowerCase());
    const stopWords = new Set(natural.stopwords);
    const filteredTokens = tokens.filter(token => 
      token.length > 3 && 
      !stopWords.has(token) && 
      /^[a-zA-Z]+$/.test(token)
    );
    
    tfidf.addDocument(filteredTokens);
    
    const keywords = [];
    tfidf.listTerms(0).slice(0, topN).forEach(item => {
      keywords.push({
        word: item.term,
        score: parseFloat(item.tfidf.toFixed(4))
      });
    });
    
    return keywords;
  } catch (error) {
    console.error('Keyword extraction error:', error);
    return [];
  }
}

// AI analysis functions
async function generateSummary(text, type = 'short') {
  try {
    const wordLimit = type === 'short' ? 150 : 500;
    const prompt = `Please provide a ${type} summary of this research paper in exactly ${wordLimit} words. Focus on the main findings, methodology, and conclusions:\n\n${text.substring(0, 4000)}`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Summary generation error:', error);
    return `Error generating ${type} summary: ${error.message}`;
  }
}

async function generateSectionSummary(sectionText, sectionName) {
  try {
    if (!sectionText || sectionText.length < 50) {
      return `${sectionName} section not found or too short to summarize.`;
    }
    
    const prompt = `Summarize this ${sectionName} section of a research paper in 2-3 sentences:\n\n${sectionText}`;
    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error(`${sectionName} summary error:`, error);
    return `Error summarizing ${sectionName} section.`;
  }
}

async function identifyResearchTopics(text) {
  try {
    const prompt = `Identify the main research topics and domains covered in this paper. List 3-5 specific research areas:\n\n${text.substring(0, 3000)}`;
    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text().split('\n').filter(topic => topic.trim().length > 0).slice(0, 5);
  } catch (error) {
    console.error('Research topics error:', error);
    return ['Error identifying research topics'];
  }
}

async function generateReviewerReport(text, sections) {
  try {
    const prompt = `As an expert academic reviewer, provide a comprehensive review of this research paper. Include:
    1. Novelty assessment (1-10 score)
    2. Clarity assessment (1-10 score)  
    3. Methodology quality (1-10 score)
    4. Overall quality (1-10 score)
    5. Key strengths (3-4 points)
    6. Key weaknesses (3-4 points)
    7. Limitations (2-3 points)
    8. Research gaps identified
    9. Future work suggestions
    
    Format your response clearly with numbered sections.\n\nPaper content:\n${text.substring(0, 5000)}`;
    
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const reviewText = response.text();
    
    // Parse scores from the review
    const noveltyMatch = reviewText.match(/novelty.*?(\d+)/i);
    const clarityMatch = reviewText.match(/clarity.*?(\d+)/i);
    const methodologyMatch = reviewText.match(/methodology.*?(\d+)/i);
    const overallMatch = reviewText.match(/overall.*?(\d+)/i);
    
    return {
      full_report: reviewText,
      scores: {
        novelty: noveltyMatch ? parseInt(noveltyMatch[1]) : 7,
        clarity: clarityMatch ? parseInt(clarityMatch[1]) : 7,
        methodology: methodologyMatch ? parseInt(methodologyMatch[1]) : 7,
        overall: overallMatch ? parseInt(overallMatch[1]) : 7
      },
      strengths: extractListItems(reviewText, 'strength'),
      weaknesses: extractListItems(reviewText, 'weakness'),
      limitations: extractListItems(reviewText, 'limitation'),
      research_gaps: extractListItems(reviewText, 'gap'),
      future_work: extractListItems(reviewText, 'future')
    };
  } catch (error) {
    console.error('Reviewer report error:', error);
    return {
      full_report: 'Error generating reviewer report',
      scores: { novelty: 5, clarity: 5, methodology: 5, overall: 5 },
      strengths: ['Error generating strengths'],
      weaknesses: ['Error generating weaknesses'],
      limitations: ['Error generating limitations'],
      research_gaps: 'Error identifying research gaps',
      future_work: 'Error generating future work suggestions'
    };
  }
}

function extractListItems(text, keyword) {
  const lines = text.split('\n');
  const items = [];
  let inSection = false;
  
  for (const line of lines) {
    if (line.toLowerCase().includes(keyword)) {
      inSection = true;
      continue;
    }
    if (inSection && (line.trim().startsWith('-') || line.trim().startsWith('•') || /^\d+\./.test(line.trim()))) {
      items.push(line.trim().replace(/^[-•\d\.]\s*/, ''));
    } else if (inSection && line.trim() === '') {
      continue;
    } else if (inSection && items.length > 0) {
      break;
    }
  }
  
  return items.length > 0 ? items : [`Error extracting ${keyword} items`];
}

// Main analysis endpoint
app.post('/analyze-paper', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({
        error: 'No file uploaded',
        message: 'Please upload a PDF file'
      });
    }

    console.log('Processing PDF file:', req.file.originalname);

    // Extract text from PDF
    const pdfData = await pdfParse(req.file.buffer);
    const rawText = pdfData.text;
    
    if (!rawText || rawText.length < 100) {
      return res.status(400).json({
        error: 'Invalid PDF',
        message: 'Could not extract sufficient text from PDF'
      });
    }

    const cleanedText = preprocessText(rawText);
    const originalWordCount = cleanedText.split(/\s+/).length;

    // Detect sections
    const sections = detectSections(cleanedText);

    // Extract keywords
    const keywords = extractKeywords(cleanedText);

    // Generate summaries
    const shortSummary = await generateSummary(cleanedText, 'short');
    const detailedSummary = await generateSummary(cleanedText, 'detailed');

    // Generate section summaries
    const sectionSummaries = {};
    for (const [sectionName, sectionText] of Object.entries(sections)) {
      if (sectionText) {
        sectionSummaries[sectionName] = await generateSectionSummary(sectionText, sectionName);
      }
    }

    // Identify research topics
    const researchTopics = await identifyResearchTopics(cleanedText);

    // Generate reviewer report
    const reviewerReport = await generateReviewerReport(cleanedText, sections);

    // Calculate analytics
    const shortSummaryWordCount = shortSummary.split(/\s+/).length;
    const detailedSummaryWordCount = detailedSummary.split(/\s+/).length;
    const compressionRatio = ((originalWordCount - shortSummaryWordCount) / originalWordCount * 100).toFixed(2);

    // Prepare response
    const response = {
      document_info: {
        filename: req.file.originalname,
        file_size_mb: (req.file.size / (1024 * 1024)).toFixed(2),
        processing_timestamp: new Date().toISOString()
      },
      text_analytics: {
        original_word_count: originalWordCount,
        short_summary_word_count: shortSummaryWordCount,
        detailed_summary_word_count: detailedSummaryWordCount,
        compression_percentage: parseFloat(compressionRatio)
      },
      keywords: keywords,
      research_topics: researchTopics,
      summaries: {
        short_summary: shortSummary,
        detailed_summary: detailedSummary
      },
      sections: sections,
      section_summaries: sectionSummaries,
      ai_reviewer_report: reviewerReport,
      processing_status: 'completed'
    };

    console.log('Analysis completed successfully');
    res.json(response);

  } catch (error) {
    console.error('Analysis error:', error);
    res.status(500).json({
      error: 'Processing failed',
      message: error.message,
      processing_status: 'failed'
    });
  }
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    service: 'AI Research Paper Analyzer'
  });
});

// Serve frontend
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'static', 'index.html'));
});

// Error handling middleware
app.use((error, req, res, next) => {
  if (error instanceof multer.MulterError) {
    if (error.code === 'LIMIT_FILE_SIZE') {
      return res.status(400).json({
        error: 'File too large',
        message: 'File size must be less than 10MB'
      });
    }
  }
  
  console.error('Unhandled error:', error);
  res.status(500).json({
    error: 'Internal server error',
    message: error.message
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 AI Research Paper Analyzer running on port ${PORT}`);
  console.log(`📊 Frontend available at: http://localhost:${PORT}`);
  console.log(`🔗 API endpoint: http://localhost:${PORT}/analyze-paper`);
});