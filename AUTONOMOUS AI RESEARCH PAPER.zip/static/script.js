// Global variables
let currentFile = null;
let analysisData = null;

// DOM elements
const uploadArea = document.getElementById('uploadArea');
const fileInput = document.getElementById('fileInput');
const fileInfo = document.getElementById('fileInfo');
const fileName = document.getElementById('fileName');
const fileSize = document.getElementById('fileSize');
const removeFileBtn = document.getElementById('removeFile');
const analyzeBtn = document.getElementById('analyzeBtn');

// Section elements
const uploadSection = document.getElementById('uploadSection');
const loadingSection = document.getElementById('loadingSection');
const resultsSection = document.getElementById('resultsSection');
const errorSection = document.getElementById('errorSection');

// Loading elements
const loadingText = document.getElementById('loadingText');
const progressFill = document.getElementById('progressFill');

// Results elements
const documentTitle = document.getElementById('documentTitle');
const downloadBtn = document.getElementById('downloadBtn');
const newAnalysisBtn = document.getElementById('newAnalysisBtn');

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeEventListeners();
});

function initializeEventListeners() {
    // File upload events
    uploadArea.addEventListener('click', () => fileInput.click());
    uploadArea.addEventListener('dragover', handleDragOver);
    uploadArea.addEventListener('dragleave', handleDragLeave);
    uploadArea.addEventListener('drop', handleDrop);
    
    fileInput.addEventListener('change', handleFileSelect);
    removeFileBtn.addEventListener('click', removeFile);
    analyzeBtn.addEventListener('click', analyzeDocument);
    
    // Action buttons
    downloadBtn.addEventListener('click', downloadReport);
    newAnalysisBtn.addEventListener('click', startNewAnalysis);
    
    // Error retry
    const retryBtn = document.getElementById('retryBtn');
    if (retryBtn) {
        retryBtn.addEventListener('click', retryAnalysis);
    }
    
    // Summary tabs
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => switchSummaryTab(btn.dataset.tab));
    });
}

// File handling functions
function handleDragOver(e) {
    e.preventDefault();
    uploadArea.classList.add('dragover');
}

function handleDragLeave(e) {
    e.preventDefault();
    uploadArea.classList.remove('dragover');
}

function handleDrop(e) {
    e.preventDefault();
    uploadArea.classList.remove('dragover');
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
        handleFile(files[0]);
    }
}

function handleFileSelect(e) {
    const file = e.target.files[0];
    if (file) {
        handleFile(file);
    }
}

function handleFile(file) {
    // Validate file type
    if (file.type !== 'application/pdf') {
        showError('Please select a PDF file.');
        return;
    }
    
    // Validate file size (10MB limit)
    const maxSize = 10 * 1024 * 1024; // 10MB in bytes
    if (file.size > maxSize) {
        showError('File size exceeds 10MB limit.');
        return;
    }
    
    currentFile = file;
    displayFileInfo(file);
}

function displayFileInfo(file) {
    fileName.textContent = file.name;
    fileSize.textContent = formatFileSize(file.size);
    
    uploadArea.style.display = 'none';
    fileInfo.style.display = 'block';
}

function removeFile() {
    currentFile = null;
    fileInput.value = '';
    
    uploadArea.style.display = 'block';
    fileInfo.style.display = 'none';
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

// Analysis functions
async function analyzeDocument() {
    if (!currentFile) {
        showError('Please select a file first.');
        return;
    }
    
    showLoadingSection();
    
    const formData = new FormData();
    formData.append('file', currentFile);
    
    try {
        // Start the loading animation
        simulateLoadingProgress();
        
        const response = await fetch('/api/analyze-paper', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.detail || 'Analysis failed');
        }
        
        analysisData = await response.json();
        showResults();
        
    } catch (error) {
        console.error('Analysis error:', error);
        showError(error.message || 'An error occurred during analysis.');
    }
}

function simulateLoadingProgress() {
    const steps = [
        { id: 'step1', text: 'Extracting text from PDF...', progress: 20 },
        { id: 'step2', text: 'Detecting document sections...', progress: 40 },
        { id: 'step3', text: 'Extracting keywords...', progress: 60 },
        { id: 'step4', text: 'Generating AI analysis...', progress: 80 },
        { id: 'step5', text: 'Finalizing results...', progress: 100 }
    ];
    
    let currentStep = 0;
    
    const interval = setInterval(() => {
        if (currentStep < steps.length) {
            const step = steps[currentStep];
            
            // Update progress bar
            progressFill.style.width = step.progress + '%';
            
            // Update loading text
            loadingText.textContent = step.text;
            
            // Update step indicators
            const stepElement = document.getElementById(step.id);
            if (stepElement) {
                stepElement.classList.add('active');
                if (currentStep > 0) {
                    const prevStep = document.getElementById(steps[currentStep - 1].id);
                    if (prevStep) {
                        prevStep.classList.remove('active');
                        prevStep.classList.add('completed');
                    }
                }
            }
            
            currentStep++;
        } else {
            clearInterval(interval);
        }
    }, 2000);
}

// Display functions
function showLoadingSection() {
    uploadSection.style.display = 'none';
    loadingSection.style.display = 'block';
    resultsSection.style.display = 'none';
    errorSection.style.display = 'none';
    
    // Reset loading state
    progressFill.style.width = '0%';
    loadingText.textContent = 'Preparing analysis...';
    
    // Reset step indicators
    const steps = document.querySelectorAll('.step');
    steps.forEach(step => {
        step.classList.remove('active', 'completed');
    });
}

function showResults() {
    uploadSection.style.display = 'none';
    loadingSection.style.display = 'none';
    resultsSection.style.display = 'block';
    errorSection.style.display = 'none';
    
    populateResults();
}

function showError(message) {
    uploadSection.style.display = 'none';
    loadingSection.style.display = 'none';
    resultsSection.style.display = 'none';
    errorSection.style.display = 'block';
    
    const errorMessage = document.getElementById('errorMessage');
    if (errorMessage) {
        errorMessage.textContent = message;
    }
}

function populateResults() {
    if (!analysisData) return;
    
    // Document title
    documentTitle.textContent = analysisData.document_title || 'Analysis Results';
    
    // Analytics
    populateAnalytics();
    
    // Reviewer scores
    populateScores();
    
    // Keywords
    populateKeywords();
    
    // Research topics
    populateTopics();
    
    // Summaries
    populateSummaries();
    
    // Section summaries
    populateSections();
    
    // Reviewer report
    populateReviewerReport();
}

function populateAnalytics() {
    const analytics = analysisData.analytics;
    
    document.getElementById('originalWords').textContent = analytics.original_word_count.toLocaleString();
    document.getElementById('processingTime').textContent = analytics.processing_time_seconds + 's';
    document.getElementById('compressionShort').textContent = analytics.compression_percentage_short + '%';
    document.getElementById('compressionDetailed').textContent = analytics.compression_percentage_detailed + '%';
}

function populateScores() {
    const scores = analysisData.reviewer_report.scores;
    
    setScore('novelty', scores.novelty);
    setScore('clarity', scores.clarity);
    setScore('methodology', scores.methodology);
    setScore('overall', scores.overall_quality);
}

function setScore(type, value) {
    const scoreFill = document.getElementById(type + 'Score');
    const scoreValue = document.getElementById(type + 'Value');
    
    if (scoreFill && scoreValue) {
        const percentage = (value / 10) * 100;
        scoreFill.style.width = percentage + '%';
        scoreValue.textContent = value + '/10';
    }
}

function populateKeywords() {
    const keywordsContainer = document.getElementById('keywordsContainer');
    keywordsContainer.innerHTML = '';
    
    analysisData.top_keywords.forEach(keyword => {
        const tag = document.createElement('span');
        tag.className = 'keyword-tag';
        tag.textContent = keyword;
        keywordsContainer.appendChild(tag);
    });
}

function populateTopics() {
    const mainTopics = document.getElementById('mainTopics');
    const secondaryTopics = document.getElementById('secondaryTopics');
    
    mainTopics.innerHTML = '';
    secondaryTopics.innerHTML = '';
    
    analysisData.research_topics.main_topics.forEach(topic => {
        const item = document.createElement('div');
        item.className = 'topic-item';
        item.textContent = topic;
        mainTopics.appendChild(item);
    });
    
    analysisData.research_topics.secondary_topics.forEach(topic => {
        const item = document.createElement('div');
        item.className = 'topic-item';
        item.textContent = topic;
        secondaryTopics.appendChild(item);
    });
}

function populateSummaries() {
    document.getElementById('shortSummaryText').textContent = analysisData.short_summary;
    document.getElementById('detailedSummaryText').textContent = analysisData.detailed_summary;
}

function populateSections() {
    const sectionsContainer = document.getElementById('sectionsContainer');
    sectionsContainer.innerHTML = '';
    
    analysisData.section_summaries.forEach(section => {
        const sectionDiv = document.createElement('div');
        sectionDiv.className = 'section-item';
        
        sectionDiv.innerHTML = `
            <div class="section-header">
                <span class="section-title">${section.section_name}</span>
                <span class="section-word-count">${section.word_count} words</span>
            </div>
            <div class="section-content">
                <div class="section-summary">${section.summary}</div>
                <div class="section-preview">${section.content}</div>
            </div>
        `;
        
        sectionsContainer.appendChild(sectionDiv);
    });
}

function populateReviewerReport() {
    const report = analysisData.reviewer_report;
    
    document.getElementById('noveltyAssessment').textContent = report.novelty_assessment;
    document.getElementById('clarityAssessment').textContent = report.clarity_assessment;
    document.getElementById('methodologyAssessment').textContent = report.methodology_quality;
    
    populateList('strengthsList', report.strengths);
    populateList('weaknessesList', report.weaknesses);
    populateList('limitationsList', report.limitations);
    populateList('gapsList', report.research_gaps);
    populateList('futureWorkList', report.future_work_suggestions);
}

function populateList(elementId, items) {
    const list = document.getElementById(elementId);
    list.innerHTML = '';
    
    items.forEach(item => {
        const li = document.createElement('li');
        li.textContent = item;
        list.appendChild(li);
    });
}

function switchSummaryTab(tabName) {
    // Update tab buttons
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
        btn.classList.toggle('active', btn.dataset.tab === tabName);
    });
    
    // Update tab content
    const summaryTabs = document.querySelectorAll('.summary-tab');
    summaryTabs.forEach(tab => {
        tab.classList.toggle('active', tab.id === tabName + 'Summary');
    });
}

// Action functions
function downloadReport() {
    if (!analysisData) return;
    
    const reportData = {
        document_title: analysisData.document_title,
        analysis_date: new Date().toISOString(),
        analytics: analysisData.analytics,
        summaries: {
            short: analysisData.short_summary,
            detailed: analysisData.detailed_summary
        },
        keywords: analysisData.top_keywords,
        research_topics: analysisData.research_topics,
        section_summaries: analysisData.section_summaries,
        reviewer_report: analysisData.reviewer_report
    };
    
    const blob = new Blob([JSON.stringify(reportData, null, 2)], {
        type: 'application/json'
    });
    
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `analysis_report_${analysisData.document_title.replace(/[^a-z0-9]/gi, '_').toLowerCase()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

function startNewAnalysis() {
    // Reset all data
    currentFile = null;
    analysisData = null;
    
    // Reset file input
    fileInput.value = '';
    
    // Show upload section
    uploadSection.style.display = 'block';
    loadingSection.style.display = 'none';
    resultsSection.style.display = 'none';
    errorSection.style.display = 'none';
    
    // Reset file info display
    uploadArea.style.display = 'block';
    fileInfo.style.display = 'none';
}

function retryAnalysis() {
    if (currentFile) {
        analyzeDocument();
    } else {
        startNewAnalysis();
    }
}

// Utility functions
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    
    // Style the notification
    Object.assign(notification.style, {
        position: 'fixed',
        top: '20px',
        right: '20px',
        padding: '15px 20px',
        borderRadius: '8px',
        color: 'white',
        fontWeight: '500',
        zIndex: '10000',
        transform: 'translateX(100%)',
        transition: 'transform 0.3s ease'
    });
    
    // Set background color based on type
    const colors = {
        info: '#667eea',
        success: '#48bb78',
        error: '#e53e3e',
        warning: '#ed8936'
    };
    notification.style.backgroundColor = colors[type] || colors.info;
    
    // Add to DOM
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}