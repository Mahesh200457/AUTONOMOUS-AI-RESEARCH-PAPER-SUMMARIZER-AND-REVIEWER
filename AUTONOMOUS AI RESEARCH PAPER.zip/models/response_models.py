from pydantic import BaseModel
from typing import List, Dict, Optional
from datetime import datetime

class SectionSummary(BaseModel):
    section_name: str
    content: str
    summary: str
    word_count: int

class ResearchTopics(BaseModel):
    main_topics: List[str]
    secondary_topics: List[str]

class ReviewerScores(BaseModel):
    novelty: int
    clarity: int
    methodology: int
    overall_quality: int

class ReviewerReport(BaseModel):
    novelty_assessment: str
    clarity_assessment: str
    methodology_quality: str
    strengths: List[str]
    weaknesses: List[str]
    limitations: List[str]
    research_gaps: List[str]
    future_work_suggestions: List[str]
    scores: ReviewerScores

class DocumentAnalytics(BaseModel):
    original_word_count: int
    short_summary_word_count: int
    detailed_summary_word_count: int
    compression_percentage_short: float
    compression_percentage_detailed: float
    processing_time_seconds: float

class AnalysisResponse(BaseModel):
    document_title: str
    extracted_text_preview: str
    detected_sections: List[str]
    section_summaries: List[SectionSummary]
    top_keywords: List[str]
    short_summary: str
    detailed_summary: str
    research_topics: ResearchTopics
    reviewer_report: ReviewerReport
    analytics: DocumentAnalytics
    timestamp: datetime